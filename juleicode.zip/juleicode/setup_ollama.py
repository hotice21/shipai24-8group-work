import subprocess, sys, os
MODEL_PATH = os.path.abspath(r"Qwen3-8B")
OLLAMA_MODEL = "qwen3-8b"

def register():
    # 写 Modelfile
    with open("Modelfile", "w", encoding="utf-8") as f:
        f.write(f"FROM {MODEL_PATH}\n")
    # 导入
    subprocess.run(["ollama app.exe", "create", OLLAMA_MODEL, "-f", "Modelfile"], check=True)
    os.remove("Modelfile")
    print("✅ 模型已注册进 Ollama，以后可直接使用！")

if __name__ == "__main__":
    register()