import subprocess, os, signal, sys
from julei import main as julei_main

OLLAMA_EXE = "ollama.exe"

def start_ollama():
    return subprocess.Popen([OLLAMA_EXE, "serve"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

if __name__ == "__main__":
    proc = start_ollama()
    try:
        julei_main()          # 运行你的主程序
    finally:
        proc.terminate()
        proc.wait()