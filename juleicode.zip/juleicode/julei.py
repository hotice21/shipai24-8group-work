import requests
import json
import re
from typing import Dict, List, Tuple
import subprocess
import time

class OllamaResumeClassifier:
    def __init__(self,
                 base_url: str = "http://localhost:11434/api/chat",
                 model: str = "qwen3:8b",
                 auto_pull: bool = True):
        self.base_url = base_url.rstrip("/")
        self.model = model

        # 1. 检测模型
        if auto_pull and not self._model_exists(model):
            # 2. 交互式确认
            ans = input(f"本地未检测到模型 '{model}'，是否立即拉取？ [Y/n] ").strip()
            if ans.lower() in ("", "y", "yes"):
                ok = self._pull_model(model)
                if not ok:  # 用户网络差/服务未启
                    raise RuntimeError("模型拉取失败，请手动执行：ollama pull " + model)
            else:
                raise RuntimeError("用户取消拉取，请先手动：ollama pull " + model)

        self.modules = {
            "个人信息": "小", "求职目标": "小", "技能关键词": "小",
            "工作经历": "小", "教育背景": "小", "实习经历": "小",
            "证书 & 培训": "小", "校内/社会活动": "小",
            "兴趣爱好": "小", "隐私声明 & 推荐人": "小"
        }
        self.module_content = {m: [] for m in self.modules}

    @staticmethod
    def _pull_model(model: str, timeout: int = 300) -> bool:
        """
        阻塞式拉模型，成功返回 True，失败 False
        """
        cmd = ["ollama", "pull", model]
        try:
            print(f"[OLLAMA] 首次使用，正在拉取模型 {model} …（预计几分钟）")
            subprocess.run(cmd, check=True, timeout=timeout)
            print(f"[OLLAMA] 模型 {model} 拉取完成！")
            return True
        except subprocess.TimeoutExpired:
            print(f"[OLLAMA] 拉取超时（>{timeout}s），请检查网络或手动执行：ollama pull {model}")
        except Exception as e:
            print(f"[OLLAMA] 拉取失败：{e}")
        return False

    @staticmethod
    def _model_exists(model: str) -> bool:
        """
        通过 ollama list 判断本地是否已有该模型
        """
        proc = subprocess.run(
            ["ollama", "list"], capture_output=True, text=True
        )
        # 输出示例：NAME    MODIFIED    SIZE
        return model in proc.stdout

    def call_ollama(self, prompt: str, model: str = "qwen3-8b") -> str:
        try:
            resp = requests.post(
                f"{self.base_url}",  # http://localhost:11434/api/chat
                json={
                    "model": self.model,
                    "messages": [{"role": "user", "content": prompt}],
                    "stream": False
                },
                timeout=120
            )
            resp.raise_for_status()
            # Ollama /api/chat 返回：{"message":{"content":"..."}}
            return resp.json()["message"]["content"].strip()
        except Exception as e:
            print(f"[call_ollama] 出错: {e}")
            return "错误: 无法获取模型响应"

    def classify_and_evaluate(self, user_input: str) -> List[Tuple[str, str, str, str]]:
            """
            返回 List[(module, value, reason, polished)]
            一句可能拆出多条
            """
            modules_list = ", ".join(self.modules.keys())

            prompt = f"""
    你是一位专业简历优化师。请按以下步骤处理用户输入：

    步骤1. 把输入拆成多个“信息点”，每点只匹配一个简历模块（{modules_list}）。
    步骤2. 对每点：
      ① 归类到最匹配的简历模块：{modules_list}
      ② 评估价值：大/中/小（“大”=有效突出用户有点；“中”=模糊；“小”=不利于展示用户优点）
      ③ 用专业简历语言改写，要求：
        - 以动词开头，量化成果，保留关键词
        - 去掉口语/情感词
        - 不超过25个中文字
      ④ 输出JSON对象，字段：
        {"{"}
          "module": "模块名",
          "value": "大/中/小",
          "reason": "一句话理由",
          "polished": "优化后的简历句"
        {"}"}

    步骤3. 把所有对象放进一个JSON数组，只返回该数组，不要解释。

    用户输入：{user_input}
    """
            response = self.call_ollama(prompt)

            # 兜底解析
            try:
                # 1. 去掉 <think>…</think> 整块
                response = re.sub(r'<think>.*?</think>', '', response, flags=re.S).strip()
                response = re.sub(r'```json|```', '', response, flags=re.I).strip()
                data = json.loads(response)
                if not isinstance(data, list):
                    data = [data]
                # 校验模块名
                cleaned = []
                for d in data:
                    mod = d.get("module", "个人信息")
                    if mod not in self.modules:
                        mod = self.find_most_relevant_module(d.get("polished", ""))
                    cleaned.append((mod, d.get("value", "中"),
                                    d.get("reason", ""), d.get("polished", "")))
                return cleaned
            except Exception as e:
                print("解析失败:", e)
                return [("个人信息", "中", "解析失败", user_input)]

    def find_most_relevant_module(self, user_input: str) -> str:
        """当模型无法正确分类时，找到最相关的模块"""
        prompt = f"""
        请分析以下用户输入，判断它最可能属于哪个简历模块：
        模块选项: {", ".join(self.modules.keys())}

        输入: "{user_input}"

        请只返回最相关的模块名称，不要有其他文本。
        """

        response = self.call_ollama(prompt).strip()

        # 检查响应是否是有效的模块名称
        for module in self.modules.keys():
            if module.lower() in response.lower():
                return module

        # 如果仍然无法确定，默认返回"个人信息"
        return "个人信息"

    def update_module_value(self, module: str, new_value: str):
        """更新模块价值"""
        if module in self.modules:
            # 价值比较：大 > 中 > 小
            value_order = {"小": 0, "中": 1, "大": 2}
            current_value = self.modules[module]
            if value_order[new_value] > value_order[current_value]:
                self.modules[module] = new_value

    def get_input_suggestion(self, user_input: str, current_module: str) -> str:
        """获取下一次输入建议"""
        # 找出价值较低的模块，建议用户补充
        low_value_modules = [module for module, value in self.modules.items() if value == "小"]

        prompt = f"""
        用户刚输入了关于"{current_module}"的信息: "{user_input}"

        当前简历模块的价值状态:
        {json.dumps(self.modules, ensure_ascii=False, indent=2)}

        请提供一句简短的建议，指导用户下一步可以输入什么内容来完善简历。
        特别关注那些当前价值为"小"的模块: {', '.join(low_value_modules)}

        只返回建议本身，不要有其他解释。
        """

        return self.call_ollama(prompt)

    def process_input(self, user_input: str) -> Dict:
        # 一次可能返回多条
        items = self.classify_and_evaluate(user_input)

        # 批量入库
        for mod, val, reason, polished in items:
            self.update_module_value(mod, val)
            self.module_content[mod].append(polished)

        # 生成下一步建议（仍用原逻辑）
        suggestion = self.get_input_suggestion(user_input, items[-1][0])
        return {
            "items": items,                       # 新增，方便前端展示
            "suggestion": suggestion,
            "current_modules": self.modules.copy(),
            "current_content": self.module_content.copy()
        }

# 主程序
def main():
    classifier = OllamaResumeClassifier()

    print("简历信息分类与价值评估系统已启动!")
    print("系统将把您的输入归类到以下模块:")
    for module in classifier.modules.keys():
        print(f"  - {module}")
    print("\n输入'退出'或'quit'结束程序\n")

    while True:
        user_input = input("请输入: ").strip()

        if user_input.lower() in ['退出', 'quit', 'exit']:
            print("感谢使用，再见!")
            break

        if not user_input:
            continue

        # 处理输入
        result = classifier.process_input(user_input)

        print("建议下一步：", result['suggestion'])
        print("当前各模块价值 & 已录入：")
        for m, v in result['current_modules'].items():
            print(f"  {m}: {v}")
            for seq, sent in enumerate(result['current_content'][m], 1):
                print(f"    {seq}. {sent}")
        print()


if __name__ == "__main__":
    main()